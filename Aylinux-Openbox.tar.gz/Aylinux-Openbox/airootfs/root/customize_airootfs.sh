#!/bin/bash

USER="aylinux"
OSNAME="Aylinux"

function initFunc() {
    set -e -u
    umask 022
}

function localeGenFunc() {
    # Set locales
    sed -i 's/#\(tr_TR\.UTF-8\)/\1/' /etc/locale.gen
    locale-gen
}

function setTimeZoneAndClockFunc() {
    # Timezone
    ln -sf /usr/share/zoneinfo/Europe/Istanbul /etc/localtime

    # Set clock to UTC
    hwclock --systohc --utc
}

function setDefaultsFunc() {
    #set default Browser
    export _BROWSER=firefox
    echo "BROWSER=/usr/bin/${_BROWSER}" >> /etc/environment
    echo "BROWSER=/usr/bin/${_BROWSER}" >> /etc/profile

    #Set Nano Editor
    export _EDITOR=nano
    echo "EDITOR=${_EDITOR}" >> /etc/environment
    echo "EDITOR=${_EDITOR}" >> /etc/profile
}

function initkeysFunc() {
    #Setup Pacman
    pacman-key --init archlinux
    pacman-key --populate archlinux
}

function fixPermissionsFunc() {
    #add missing /media directory
    mkdir -p /media
    chmod 755 -R /media

    #fix permissions
    chown root:root /usr
    chmod 755 /etc
}

function enableServicesFunc() {
    systemctl enable pacman-init.service lightdm-plymouth.service choose-mirror.service
    systemctl enable org.cups.cupsd.service
    systemctl enable smb.service
    systemctl enable nmb.service
    systemctl enable avahi-daemon.service
# systemctl enable vboxservice.service
    systemctl enable haveged
    systemctl enable pcscd
#    systemctl enable bluetooth.service
    systemctl enable graphical.target
    systemctl enable systemd-networkd.service
    systemctl enable systemd-resolved.service
    systemctl -fq enable NetworkManager
    systemctl mask systemd-rfkill@.service
    systemctl set-default graphical.target
}

function fixWifiFunc() {
#Wifi not available with networkmanager
su -c 'echo "" >> /etc/NetworkManager/NetworkManager.conf'
su -c 'echo "[device]" >> /etc/NetworkManager/NetworkManager.conf'
su -c 'echo "wifi.scan-rand-mac-address=no" >> /etc/NetworkManager/NetworkManager.conf'
}

function deleteObsoletePackagesFunc() {
# delete obsolete network packages
pacman -Rns --noconfirm openresolv netctl dhcpcd
}

function enableSudoFunc() {
    chmod 750 /etc/sudoers.d
    chmod 440 /etc/sudoers.d/g_wheel
    chown -R root /etc/sudoers.d
    chmod -R 755 /etc/sudoers.d
    echo "Sudo aktif edildi"
}

function enableSambaShare() {
    mkdir -p /var/lib/samba/usershare
    groupadd -r sambashare
    chown root:sambashare /var/lib/samba/usershare
    chmod 1770 /var/lib/samba/usershare
    sambayolu='/etc/samba/smb.conf'
 #   rm -rf $osReleasePath
    touch $sambayolu
    echo 'usershare path = /var/lib/samba/usershare' >> $sambayolu
    echo 'usershare max shares = 100' >> $sambayolu
    echo 'usershare allow guests = yes' >> $sambayolu
    echo 'usershare owner only = yes' >> $sambayolu
    echo "SambaShare tamamlandı"
}

function enableCalamaresAutostartFunc() {
    #Calamares Masaüstü Aktif
     #ln -s /usr/share/applications/calamares.desktop /home/aylinux/Desktop/calamares.desktop
     #chown aylinux /home/aylinux/Desktop/calamares.desktop
    # chmod +rx /home/aylinux/Desktop/calamares.desktop
     chmod +rx /home/$USER/Desktop/benioku.desktop
     chown $USER /home/$USER/Desktop/benioku.desktop
    #Cairo Dock Fallback kaldırmak için
     #rm /usr/share/applications/cairo-dock-cairo.desktop
}


function configRootUserFunc() {
    usermod -s /usr/bin/bash root
    echo 'export PROMPT_COMMAND=""' >> /root/.bashrc
    chmod 700 /root
}

function createLiveUserFunc () {
    # add groups autologin and nopasswdlogin (lightdm otomatik giriş için)
    groupadd -r autologin
    groupadd -r nopasswdlogin


    # add liveuser
    id -u $USER &>/dev/null || useradd -m $USER -g users -G "adm,audio,lp,floppy,log,network,rfkill,scanner,storage,optical,power,sambashare,wheel,autologin,nopasswdlogin"
    passwd -d $USER
    echo 'Canlı Kullanıcı Eklendi'
}

function editOrCreateConfigFilesFunc () {
    # Locale
    echo "LANG=tr_TR.UTF-8" > /etc/locale.conf
    echo "LC_COLLATE=C" >> /etc/locale.conf

    # Vconsole
    echo "KEYMAP=trq" > /etc/vconsole.conf
    echo "FONT=iso09.16" >> /etc/vconsole.conf

    # Hostname
    echo "aylinux" > /etc/hostname

    sed -i "s/#Server/Server/g" /etc/pacman.d/mirrorlist
    sed -i 's/#\(Storage=\)auto/\1volatile/' /etc/systemd/journald.conf
}

function renameOSFunc() {
    #Name Aylinux
    osReleasePath='/usr/lib/os-release'
    rm -rf $osReleasePath
    touch $osReleasePath
    echo 'NAME="'${OSNAME}'"' >> $osReleasePath
    echo 'ID=Aylinux' >> $osReleasePath
    echo 'PRETTY_NAME="'${OSNAME}'"' >> $osReleasePath
    echo 'ANSI_COLOR="0;35"' >> $osReleasePath
    echo 'HOME_URL="http://aylinux.org"' >> $osReleasePath
    echo 'SUPPORT_URL="http://aylinux.org/forum"' >> $osReleasePath
    echo 'BUG_REPORT_URL="http://aylinux.org/forum"' >> $osReleasePath

    arch=`uname -m`
}

function temasil() {
    #Name Aylinux
    temasil='/usr/share/themes/Mint-X*'
    rm -rf $temasil
    rm -rf /usr/share/applications/lftp.desktop
    rm -rf /usr/share/applications/qv4l2.desktop
    rm -rf /usr/share/applications/uxterm.desktop
    rm -rf /usr/share/applications/xterm.desktop
    rm -rf /usr/share/applications/cups.desktop
    rm -rf /usr/share/applications/bssh.desktop
    rm -rf /usr/share/applications/bvnc.desktop
    rm -rf /usr/share/applications/avahi-discover.desktop
    rm -rf /usr/share/applications/cinnamon-onscreen-keyboard.desktop
    rm -rf /usr/share/applications/vim.desktop
    rm -rf /usr/share/applications/org.kde.kirigami2.gallery.desktop
    rm -rf /usr/share/applications/mintstick-format-kde.desktop
    rm -rf /usr/share/applications/mintstick-kde.desktop
    rm -rf /usr/share/applications/gksu-properties.desktop
    rm -rf /usr/share/applications/hplip.desktop
    rm -rf /usr/share/applications/uyap_sablon.desktop
    rm -rf /usr/share/applications/sun_java-jre8.desktop
    rm -rf /usr/share/applications/policytool-jre8.desktop
    rm -rf /usr/share/applications/flash-player-properties.desktop
}


function mebsertifika() {
wget http://sertifika.meb.gov.tr/MEB_SERTIFIKASI.cer
sudo openssl x509 -inform DER -in MEB_SERTIFIKASI.cer -out MEB_SERTIFIKASI.crt
sudo cp MEB_SERTIFIKASI.crt /usr/local/share/ca-certificates/
sudo cp MEB_SERTIFIKASI.crt /etc/ca-certificates/trust-source/anchors/
sudo cp MEB_SERTIFIKASI.crt /etc/ssl/certs/
sudo trust extract-compat
    echo "MEB Sertifika Kuruldu"
rm MEB_SERTIFIKASI.cer
rm MEB_SERTIFIKASI.crt
#Libreoffice için Türkçe kontrol
wget https://extensions.libreoffice.org/extensions/turkish-spellcheck-dictionary/1.2/@@download/file/oo-turkish-dict-v1-2.oxt
sudo unopkg add --shared oo-turkish-dict-v1-2.oxt
rm oo-turkish-dict-v1-2.oxt
}

initFunc
initkeysFunc
localeGenFunc
#setTimeZoneAndClockFunc
editOrCreateConfigFilesFunc
configRootUserFunc
enableSambaShare
createLiveUserFunc
renameOSFunc
temasil
#fixWifiFunc
deleteObsoletePackagesFunc
setDefaultsFunc
enableSudoFunc
enableCalamaresAutostartFunc
enableServicesFunc
mebsertifika
fixPermissionsFunc
